# Removes everything this datapack added. Run, then: datapack disable "file/meowcraft_stats.zip"
schedule clear meowcraft:nap_check
schedule clear meowcraft:update
schedule clear meowcraft:rotate
scoreboard objectives remove mc_fall_cm
scoreboard objectives remove mc_fall
scoreboard objectives remove mc_sneak_t
scoreboard objectives remove mc_sneak
scoreboard objectives remove mc_nap_t
scoreboard objectives remove mc_nap
scoreboard objectives remove mc_jumps
scoreboard objectives remove mc_dirt
scoreboard objectives remove mc_drops
scoreboard objectives remove mc_deaths
scoreboard objectives remove mc_fish
scoreboard objectives remove mc_cake
scoreboard objectives remove mc_bred
scoreboard objectives remove mc_creeper
scoreboard objectives remove mc_trades
scoreboard objectives remove mc_puffer
scoreboard objectives remove mc_sys
scoreboard objectives remove mystats
scoreboard objectives remove achievements
scoreboard objectives remove title
team remove mct_fall1
team remove mct_fall2
team remove mct_sneak1
team remove mct_sneak2
team remove mct_nap1
team remove mct_nap2
team remove mct_jump1
team remove mct_jump2
team remove mct_dirt1
team remove mct_dirt2
team remove mct_drop1
team remove mct_drop2
team remove mct_lives1
team remove mct_lives2
team remove mct_fish1
team remove mct_fish2
team remove mct_cake1
team remove mct_cake2
team remove mct_bred1
team remove mct_bred2
team remove mct_creeper1
team remove mct_creeper2
team remove mct_trade1
team remove mct_trade2
team remove mct_puffer1
tag @a remove mc_t_fall1
tag @a remove mc_r_fall1
tag @a remove mc_t_fall2
tag @a remove mc_r_fall2
tag @a remove mc_t_sneak1
tag @a remove mc_r_sneak1
tag @a remove mc_t_sneak2
tag @a remove mc_r_sneak2
tag @a remove mc_t_nap1
tag @a remove mc_r_nap1
tag @a remove mc_t_nap2
tag @a remove mc_r_nap2
tag @a remove mc_t_jump1
tag @a remove mc_r_jump1
tag @a remove mc_t_jump2
tag @a remove mc_r_jump2
tag @a remove mc_t_dirt1
tag @a remove mc_r_dirt1
tag @a remove mc_t_dirt2
tag @a remove mc_r_dirt2
tag @a remove mc_t_drop1
tag @a remove mc_r_drop1
tag @a remove mc_t_drop2
tag @a remove mc_r_drop2
tag @a remove mc_t_lives1
tag @a remove mc_r_lives1
tag @a remove mc_t_lives2
tag @a remove mc_r_lives2
tag @a remove mc_t_fish1
tag @a remove mc_r_fish1
tag @a remove mc_t_fish2
tag @a remove mc_r_fish2
tag @a remove mc_t_cake1
tag @a remove mc_r_cake1
tag @a remove mc_t_cake2
tag @a remove mc_r_cake2
tag @a remove mc_t_bred1
tag @a remove mc_r_bred1
tag @a remove mc_t_bred2
tag @a remove mc_r_bred2
tag @a remove mc_t_creeper1
tag @a remove mc_r_creeper1
tag @a remove mc_t_creeper2
tag @a remove mc_r_creeper2
tag @a remove mc_t_trade1
tag @a remove mc_r_trade1
tag @a remove mc_t_trade2
tag @a remove mc_r_trade2
tag @a remove mc_t_puffer1
tag @a remove mc_r_puffer1
