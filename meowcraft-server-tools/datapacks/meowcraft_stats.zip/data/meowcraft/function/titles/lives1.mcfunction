tag @s add mc_t_lives1
tellraw @a ["", {"text": "[Meowcraft] ", "color": "dark_purple"}, {"selector": "@s", "color": "dark_red"}, {"text": " has died 9 times. Cats only get nine, you know.", "color": "white"}]
tellraw @a ["", {"text": "   New title: ", "color": "gray"}, {"text": "Used Up All Nine Lives", "color": "dark_red", "bold": true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
