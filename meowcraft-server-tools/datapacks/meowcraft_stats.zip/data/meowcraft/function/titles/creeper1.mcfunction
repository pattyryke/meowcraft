tag @s add mc_t_creeper1
tellraw @a ["", {"text": "[Meowcraft] ", "color": "dark_purple"}, {"selector": "@s", "color": "green"}, {"text": " has been blown up by creepers 3 times. They just wanted a hug.", "color": "white"}]
tellraw @a ["", {"text": "   New title: ", "color": "gray"}, {"text": "Creeper Hugger", "color": "green", "bold": true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
