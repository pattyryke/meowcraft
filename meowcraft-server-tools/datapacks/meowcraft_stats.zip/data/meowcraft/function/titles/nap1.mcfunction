tag @s add mc_t_nap1
tellraw @a ["", {"text": "[Meowcraft] ", "color": "dark_purple"}, {"selector": "@s", "color": "aqua"}, {"text": " has spent a full minute asleep. Very cat of them.", "color": "white"}]
tellraw @a ["", {"text": "   New title: ", "color": "gray"}, {"text": "Power Napper", "color": "aqua", "bold": true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
