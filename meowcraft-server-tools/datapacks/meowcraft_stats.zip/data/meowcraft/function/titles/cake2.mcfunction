tag @s add mc_t_cake2
tellraw @a ["", {"text": "[Meowcraft] ", "color": "dark_purple"}, {"selector": "@s", "color": "light_purple"}, {"text": " has eaten 100 slices of cake. Somebody stop them.", "color": "white"}]
tellraw @a ["", {"text": "   New title: ", "color": "gray"}, {"text": "The Cake Is Not a Lie", "color": "light_purple", "bold": true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
