tag @s add mc_t_cake1
tellraw @a ["", {"text": "[Meowcraft] ", "color": "dark_purple"}, {"selector": "@s", "color": "light_purple"}, {"text": " has eaten 10 slices of cake. Was it a birthday? Every day is a birthday.", "color": "white"}]
tellraw @a ["", {"text": "   New title: ", "color": "gray"}, {"text": "Cake Enthusiast", "color": "light_purple", "bold": true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
