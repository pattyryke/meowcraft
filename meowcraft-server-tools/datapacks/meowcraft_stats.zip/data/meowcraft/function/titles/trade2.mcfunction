tag @s add mc_t_trade2
tellraw @a ["", {"text": "[Meowcraft] ", "color": "dark_purple"}, {"selector": "@s", "color": "dark_aqua"}, {"text": " has traded with villagers 500 times. HMMMM.", "color": "white"}]
tellraw @a ["", {"text": "   New title: ", "color": "gray"}, {"text": "Emerald Goblin", "color": "dark_aqua", "bold": true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
