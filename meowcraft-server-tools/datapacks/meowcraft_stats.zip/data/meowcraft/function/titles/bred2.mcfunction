tag @s add mc_t_bred2
tellraw @a ["", {"text": "[Meowcraft] ", "color": "dark_purple"}, {"selector": "@s", "color": "red"}, {"text": " has bred 250 animals. The farm is getting crowded.", "color": "white"}]
tellraw @a ["", {"text": "   New title: ", "color": "gray"}, {"text": "Cupid", "color": "red", "bold": true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
