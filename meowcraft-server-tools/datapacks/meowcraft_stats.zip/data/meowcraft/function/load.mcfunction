# Meowcraft Silly Stats - runs on server start and /reload

# Raw stats (counted by Minecraft itself)
scoreboard objectives add mc_fall_cm minecraft.custom:minecraft.fall_one_cm
scoreboard objectives add mc_sneak_t minecraft.custom:minecraft.sneak_time
scoreboard objectives add mc_nap_t dummy
scoreboard objectives add mc_jumps minecraft.custom:minecraft.jump {"text": "Bunny Hops", "color": "#FFB38A", "bold": true}
scoreboard objectives add mc_dirt minecraft.picked_up:minecraft.dirt {"text": "Dirt Hoarder", "color": "#E0B07A", "bold": true}
scoreboard objectives add mc_drops minecraft.custom:minecraft.drop {"text": "Butterfingers", "color": "#FFE27A", "bold": true}
scoreboard objectives add mc_deaths minecraft.custom:minecraft.deaths {"text": "Nine Lives", "color": "#FF6B6B", "bold": true}
scoreboard objectives add mc_fish minecraft.custom:minecraft.fish_caught {"text": "Fish Whisperer", "color": "#6EC6FF", "bold": true}
scoreboard objectives add mc_cake minecraft.custom:minecraft.eat_cake_slice {"text": "Cake Time", "color": "#FFC2E2", "bold": true}
scoreboard objectives add mc_bred minecraft.custom:minecraft.animals_bred {"text": "Matchmaker", "color": "#FF9ECF", "bold": true}
scoreboard objectives add mc_creeper minecraft.killed_by:minecraft.creeper {"text": "Creeper Hugs", "color": "#7CD992", "bold": true}
scoreboard objectives add mc_trades minecraft.custom:minecraft.traded_with_villager {"text": "Haggler", "color": "#5BE3B0", "bold": true}
scoreboard objectives add mc_puffer minecraft.used:minecraft.pufferfish {"text": "Bad Sushi", "color": "#FFD166", "bold": true}

# Friendly display versions (converted units)
scoreboard objectives add mc_fall dummy {"text": "Faceplant", "color": "#FF8FB1", "bold": true}
scoreboard objectives add mc_sneak dummy {"text": "Gremlin Mode", "color": "#7FE0A8", "bold": true}
scoreboard objectives add mc_nap dummy {"text": "Nap Time", "color": "#B9A3FF", "bold": true}

# Helpers
scoreboard objectives add mc_sys dummy
scoreboard objectives add mystats trigger
scoreboard objectives add achievements trigger
scoreboard objectives add title trigger
scoreboard players set #100 mc_sys 100
scoreboard players set #20 mc_sys 20
scoreboard players set #6 mc_sys 6

# --- Cute sidebar styling ---
scoreboard players reset meow_footer
scoreboard players reset meow_space_bottom
scoreboard objectives modify mc_fall displayname ["", {"text": "☁ ", "color": "white"}, {"text": "Faceplant", "color": "#FF8FB1", "bold": true}, {"text": " ☁", "color": "white"}]
scoreboard objectives modify mc_fall numberformat styled {"color": "#FF8FB1", "bold": true}
scoreboard players set meow_space_top mc_fall 2147483647
scoreboard players display name meow_space_top mc_fall {"text":" "}
scoreboard players display numberformat meow_space_top mc_fall blank
scoreboard objectives modify mc_sneak displayname ["", {"text": "✦ ", "color": "white"}, {"text": "Gremlin Mode", "color": "#7FE0A8", "bold": true}, {"text": " ✦", "color": "white"}]
scoreboard objectives modify mc_sneak numberformat styled {"color": "#7FE0A8", "bold": true}
scoreboard players set meow_space_top mc_sneak 2147483647
scoreboard players display name meow_space_top mc_sneak {"text":" "}
scoreboard players display numberformat meow_space_top mc_sneak blank
scoreboard objectives modify mc_nap displayname ["", {"text": "☾ ", "color": "white"}, {"text": "Nap Time", "color": "#B9A3FF", "bold": true}, {"text": " ☾", "color": "white"}]
scoreboard objectives modify mc_nap numberformat styled {"color": "#B9A3FF", "bold": true}
scoreboard players set meow_space_top mc_nap 2147483647
scoreboard players display name meow_space_top mc_nap {"text":" "}
scoreboard players display numberformat meow_space_top mc_nap blank
scoreboard objectives modify mc_jumps displayname ["", {"text": "❀ ", "color": "white"}, {"text": "Bunny Hops", "color": "#FFB38A", "bold": true}, {"text": " ❀", "color": "white"}]
scoreboard objectives modify mc_jumps numberformat styled {"color": "#FFB38A", "bold": true}
scoreboard players set meow_space_top mc_jumps 2147483647
scoreboard players display name meow_space_top mc_jumps {"text":" "}
scoreboard players display numberformat meow_space_top mc_jumps blank
scoreboard objectives modify mc_dirt displayname ["", {"text": "✿ ", "color": "white"}, {"text": "Dirt Hoarder", "color": "#E0B07A", "bold": true}, {"text": " ✿", "color": "white"}]
scoreboard objectives modify mc_dirt numberformat styled {"color": "#E0B07A", "bold": true}
scoreboard players set meow_space_top mc_dirt 2147483647
scoreboard players display name meow_space_top mc_dirt {"text":" "}
scoreboard players display numberformat meow_space_top mc_dirt blank
scoreboard objectives modify mc_drops displayname ["", {"text": "♥ ", "color": "white"}, {"text": "Butterfingers", "color": "#FFE27A", "bold": true}, {"text": " ♥", "color": "white"}]
scoreboard objectives modify mc_drops numberformat styled {"color": "#FFE27A", "bold": true}
scoreboard players set meow_space_top mc_drops 2147483647
scoreboard players display name meow_space_top mc_drops {"text":" "}
scoreboard players display numberformat meow_space_top mc_drops blank

# No sidebar - tab list shows blocks fallen
scoreboard objectives setdisplay sidebar
scoreboard objectives setdisplay list mc_fall

# Start the loops
schedule function meowcraft:nap_check 5t replace
schedule function meowcraft:update 1s replace
schedule clear meowcraft:rotate

# One team per title: its prefix shows above heads, in the Tab list and (via EssentialsChat {TEAMPREFIX}) in chat
team add mct_fall1
team modify mct_fall1 prefix {"text": "☁ ", "color": "red", "bold": false}
team add mct_fall2
team modify mct_fall2 prefix {"text": "☄ ", "color": "red", "bold": false}
team add mct_sneak1
team modify mct_sneak1 prefix {"text": "ʰᵉʰ ", "color": "dark_green", "bold": false}
team add mct_sneak2
team modify mct_sneak2 prefix {"text": "✧ʰᵉʰ✧ ", "color": "dark_green", "bold": false}
team add mct_nap1
team modify mct_nap1 prefix {"text": "ᶻᶻ ", "color": "aqua", "bold": false}
team add mct_nap2
team modify mct_nap2 prefix {"text": "☾ᶻᶻᶻ ", "color": "aqua", "bold": false}
team add mct_jump1
team modify mct_jump1 prefix {"text": "⇡ ", "color": "light_purple", "bold": false}
team add mct_jump2
team modify mct_jump2 prefix {"text": "ʙᴏɪɴɢ ", "color": "light_purple", "bold": false}
team add mct_dirt1
team modify mct_dirt1 prefix {"text": "▪ ", "color": "gold", "bold": false}
team add mct_dirt2
team modify mct_dirt2 prefix {"text": "♛▪ ", "color": "gold", "bold": false}
team add mct_drop1
team modify mct_drop1 prefix {"text": "ᵒᵒᵖˢ ", "color": "yellow", "bold": false}
team add mct_drop2
team modify mct_drop2 prefix {"text": "ᵒᵒᵖˢ! ", "color": "yellow", "bold": false}
team add mct_lives1
team modify mct_lives1 prefix {"text": "☠ ", "color": "dark_red", "bold": false}
team add mct_lives2
team modify mct_lives2 prefix {"text": "☠☠ ", "color": "dark_red", "bold": false}
team add mct_fish1
team modify mct_fish1 prefix {"text": "><> ", "color": "blue", "bold": false}
team add mct_fish2
team modify mct_fish2 prefix {"text": "≋><> ", "color": "blue", "bold": false}
team add mct_cake1
team modify mct_cake1 prefix {"text": "ᶜᵃᵏᵉ ", "color": "light_purple", "bold": false}
team add mct_cake2
team modify mct_cake2 prefix {"text": "♚ᶜᵃᵏᵉ ", "color": "light_purple", "bold": false}
team add mct_bred1
team modify mct_bred1 prefix {"text": "♡ ", "color": "red", "bold": false}
team add mct_bred2
team modify mct_bred2 prefix {"text": "♡♡ ", "color": "red", "bold": false}
team add mct_creeper1
team modify mct_creeper1 prefix {"text": "✸ ", "color": "green", "bold": false}
team add mct_creeper2
team modify mct_creeper2 prefix {"text": "ᵇᵒᵒᵐ ", "color": "green", "bold": false}
team add mct_trade1
team modify mct_trade1 prefix {"text": "ʰᵐᵐ ", "color": "dark_aqua", "bold": false}
team add mct_trade2
team modify mct_trade2 prefix {"text": "ʰᵐᵐᵐᵐ ", "color": "dark_aqua", "bold": false}
team add mct_puffer1
team modify mct_puffer1 prefix {"text": "ᵇˡᵉʰ ", "color": "gold", "bold": false}
