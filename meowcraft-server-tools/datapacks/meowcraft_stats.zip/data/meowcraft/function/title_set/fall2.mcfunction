team join mct_fall2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "☄ Gravity's Favorite Toy", "color": "red"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
