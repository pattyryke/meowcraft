team join mct_sneak1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "✧ Certified Gremlin", "color": "dark_green"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
