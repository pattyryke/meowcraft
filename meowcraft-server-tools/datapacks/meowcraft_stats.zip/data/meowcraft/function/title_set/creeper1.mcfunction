team join mct_creeper1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "✸ Creeper Hugger", "color": "green"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
