team join mct_cake2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "♚ The Cake Is Not a Lie", "color": "light_purple"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
