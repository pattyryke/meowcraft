team join mct_jump1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "⇡ Bunny in Training", "color": "light_purple"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
