team join mct_fish1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "><> Fish Whisperer", "color": "blue"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
