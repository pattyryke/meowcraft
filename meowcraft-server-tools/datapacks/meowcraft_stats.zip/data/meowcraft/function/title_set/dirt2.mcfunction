team join mct_dirt2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "♛ Supreme Dirt Lord", "color": "gold"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
