team join mct_creeper2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "ᵇᵒᵒᵐ Creeper's Best Friend", "color": "green"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
