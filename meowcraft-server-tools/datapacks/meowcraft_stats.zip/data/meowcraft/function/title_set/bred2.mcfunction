team join mct_bred2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "♡♡ Cupid", "color": "red"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
