team join mct_trade2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "◆ Emerald Goblin", "color": "dark_aqua"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
