team join mct_cake1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "♨ Cake Enthusiast", "color": "light_purple"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
