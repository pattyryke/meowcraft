team join mct_puffer1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "✺ Bad Sushi", "color": "gold"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
