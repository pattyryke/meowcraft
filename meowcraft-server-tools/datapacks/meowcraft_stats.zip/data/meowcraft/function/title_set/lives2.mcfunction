team join mct_lives2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "☠☠ Professional Respawner", "color": "dark_red"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
