team join mct_jump2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "ʙᴏɪɴɢ Hop Lord", "color": "light_purple"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
