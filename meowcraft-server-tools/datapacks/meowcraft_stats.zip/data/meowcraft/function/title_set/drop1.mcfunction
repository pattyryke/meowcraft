team join mct_drop1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "ᵒᵒᵖˢ Butterfingers", "color": "yellow"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
