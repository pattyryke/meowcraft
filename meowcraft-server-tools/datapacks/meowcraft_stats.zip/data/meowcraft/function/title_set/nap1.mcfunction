team join mct_nap1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "ᶻᶻ Power Napper", "color": "aqua"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
