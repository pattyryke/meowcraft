team join mct_dirt1 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "▪ Dirt Enthusiast", "color": "gold"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
