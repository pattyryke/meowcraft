team join mct_nap2 @s
tellraw @s ["", {"text": "Now wearing ", "color": "gray"}, {"text": "☾ᶻᶻᶻ Professional Cat Napper", "color": "aqua"}, {"text": " =^.^=", "color": "#B9A3FF"}]
playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1.2
