# Handles /trigger title
execute if score @s title matches 1..98 run function meowcraft:title_menu
execute if score @s title matches 99 run function meowcraft:title_clear
execute if score @s title matches 100.. run function meowcraft:title_pick
scoreboard players set @s title 0
