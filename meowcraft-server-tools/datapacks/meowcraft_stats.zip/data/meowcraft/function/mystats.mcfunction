# Private stat card for whoever ran /trigger mystats
tellraw @s ["", {"text": "=^.^= ", "color": "#B9A3FF"}, {"selector": "@s", "color": "light_purple"}, {"text": "'s Silly Stats =^.^=", "color": "#B9A3FF"}]
tellraw @s ["", {"text": " Faceplant: ", "color": "#FF8FB1"}, {"score": {"name": "@s", "objective": "mc_fall"}}, {"text": " blocks fallen", "color": "gray"}]
tellraw @s ["", {"text": " Gremlin Mode: ", "color": "#7FE0A8"}, {"score": {"name": "@s", "objective": "mc_sneak"}}, {"text": " sec sneaking", "color": "gray"}]
tellraw @s ["", {"text": " Nap Time: ", "color": "#B9A3FF"}, {"score": {"name": "@s", "objective": "mc_nap"}}, {"text": " sec asleep", "color": "gray"}]
tellraw @s ["", {"text": " Bunny Hops: ", "color": "#FFB38A"}, {"score": {"name": "@s", "objective": "mc_jumps"}}, {"text": " jumps", "color": "gray"}]
tellraw @s ["", {"text": " Dirt Hoarder: ", "color": "#E0B07A"}, {"score": {"name": "@s", "objective": "mc_dirt"}}, {"text": " dirt collected", "color": "gray"}]
tellraw @s ["", {"text": " Butterfingers: ", "color": "#FFE27A"}, {"score": {"name": "@s", "objective": "mc_drops"}}, {"text": " items dropped", "color": "gray"}]
tellraw @s ["", {"text": " Nine Lives: ", "color": "#FF6B6B"}, {"score": {"name": "@s", "objective": "mc_deaths"}}, {"text": " deaths", "color": "gray"}]
tellraw @s ["", {"text": " Fish Whisperer: ", "color": "#6EC6FF"}, {"score": {"name": "@s", "objective": "mc_fish"}}, {"text": " fish caught", "color": "gray"}]
tellraw @s ["", {"text": " Cake Time: ", "color": "#FFC2E2"}, {"score": {"name": "@s", "objective": "mc_cake"}}, {"text": " cake slices", "color": "gray"}]
tellraw @s ["", {"text": " Matchmaker: ", "color": "#FF9ECF"}, {"score": {"name": "@s", "objective": "mc_bred"}}, {"text": " animals bred", "color": "gray"}]
tellraw @s ["", {"text": " Creeper Hugs: ", "color": "#7CD992"}, {"score": {"name": "@s", "objective": "mc_creeper"}}, {"text": " creeper deaths", "color": "gray"}]
tellraw @s ["", {"text": " Haggler: ", "color": "#5BE3B0"}, {"score": {"name": "@s", "objective": "mc_trades"}}, {"text": " villager trades", "color": "gray"}]
tellraw @s {"text": " See every achievement: /trigger achievements   Wear a title: /trigger title", "color": "dark_gray", "italic": true}
scoreboard players set @s mystats 0
