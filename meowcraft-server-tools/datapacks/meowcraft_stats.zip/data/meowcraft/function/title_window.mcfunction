# Macro: shows the title window built by title_menu
$dialog show @s {type:"minecraft:multi_action",title:{text:"=^.^= Pick a title =^.^=",color:"#B9A3FF"},body:{type:"minecraft:plain_message",contents:{text:"$(body)"}},actions:$(actions),columns:1,exit_action:{label:{text:"Close"}}}
