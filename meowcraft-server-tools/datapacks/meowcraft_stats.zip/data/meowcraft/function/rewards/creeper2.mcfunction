tag @s add mc_r_creeper2
xp add @s 15 levels
give @s minecraft:gunpowder[custom_name={text:"Creeper's Best Friend Trophy",color:"#7CD992",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Creeper's Best Friend", "color": "green"}, {"text": ": 15 XP levels and a Creeper's Best Friend Trophy! ", "color": "gray"}, {"text": "Wear it: /trigger title", "color": "dark_gray", "italic": true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
