tag @s add mc_r_drop1
xp add @s 5 levels
give @s minecraft:cookie[custom_name={text:"Meowcraft Treat",color:"#FFB38A",italic:false}] 8
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Butterfingers", "color": "yellow"}, {"text": ": 5 XP levels and 8 Meowcraft Treats!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
