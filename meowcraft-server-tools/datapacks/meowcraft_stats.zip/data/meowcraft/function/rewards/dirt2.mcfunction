tag @s add mc_r_dirt2
xp add @s 15 levels
give @s minecraft:dirt[custom_name={text:"Supreme Dirt Lord Trophy",color:"#E0B07A",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Supreme Dirt Lord", "color": "gold"}, {"text": ": 15 XP levels and a Supreme Dirt Lord Trophy!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
