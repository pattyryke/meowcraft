tag @s add mc_r_sneak2
xp add @s 15 levels
give @s minecraft:ink_sac[custom_name={text:"Shadow Goblin Supreme Trophy",color:"#7FE0A8",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Shadow Goblin Supreme", "color": "dark_green"}, {"text": ": 15 XP levels and a Shadow Goblin Supreme Trophy!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
