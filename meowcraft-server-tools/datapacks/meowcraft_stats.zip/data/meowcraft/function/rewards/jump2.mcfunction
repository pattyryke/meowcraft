tag @s add mc_r_jump2
xp add @s 15 levels
give @s minecraft:rabbit_foot[custom_name={text:"Hop Lord Trophy",color:"#FFB38A",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Hop Lord", "color": "light_purple"}, {"text": ": 15 XP levels and a Hop Lord Trophy! ", "color": "gray"}, {"text": "Wear it: /trigger title", "color": "dark_gray", "italic": true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
