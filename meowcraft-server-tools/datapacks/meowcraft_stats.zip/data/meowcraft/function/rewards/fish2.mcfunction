tag @s add mc_r_fish2
xp add @s 15 levels
give @s minecraft:cod[custom_name={text:"The Ocean Fears Them Trophy",color:"#6EC6FF",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "The Ocean Fears Them", "color": "blue"}, {"text": ": 15 XP levels and a The Ocean Fears Them Trophy!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
