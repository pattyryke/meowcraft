tag @s add mc_r_cake2
xp add @s 15 levels
give @s minecraft:cake[custom_name={text:"The Cake Is Not a Lie Trophy",color:"#FFC2E2",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "The Cake Is Not a Lie", "color": "light_purple"}, {"text": ": 15 XP levels and a The Cake Is Not a Lie Trophy!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
