tag @s add mc_r_lives2
xp add @s 15 levels
give @s minecraft:bone[custom_name={text:"Professional Respawner Trophy",color:"#FF6B6B",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Professional Respawner", "color": "dark_red"}, {"text": ": 15 XP levels and a Professional Respawner Trophy! ", "color": "gray"}, {"text": "Wear it: /trigger title", "color": "dark_gray", "italic": true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
