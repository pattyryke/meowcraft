tag @s add mc_r_bred2
xp add @s 15 levels
give @s minecraft:poppy[custom_name={text:"Cupid Trophy",color:"#FF9ECF",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Cupid", "color": "red"}, {"text": ": 15 XP levels and a Cupid Trophy! ", "color": "gray"}, {"text": "Wear it: /trigger title", "color": "dark_gray", "italic": true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
