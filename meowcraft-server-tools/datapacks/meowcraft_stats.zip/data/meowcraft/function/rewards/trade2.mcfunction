tag @s add mc_r_trade2
xp add @s 15 levels
give @s minecraft:emerald[custom_name={text:"Emerald Goblin Trophy",color:"#5BE3B0",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Emerald Goblin", "color": "dark_aqua"}, {"text": ": 15 XP levels and a Emerald Goblin Trophy! ", "color": "gray"}, {"text": "Wear it: /trigger title", "color": "dark_gray", "italic": true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
