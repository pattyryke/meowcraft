tag @s add mc_r_fall2
xp add @s 15 levels
give @s minecraft:feather[custom_name={text:"Gravity's Favorite Toy Trophy",color:"#FF8FB1",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Gravity's Favorite Toy", "color": "red"}, {"text": ": 15 XP levels and a Gravity's Favorite Toy Trophy!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
