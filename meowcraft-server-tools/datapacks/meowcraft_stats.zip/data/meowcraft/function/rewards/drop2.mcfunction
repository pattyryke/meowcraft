tag @s add mc_r_drop2
xp add @s 15 levels
give @s minecraft:gold_ingot[custom_name={text:"Slippery Paws Trophy",color:"#FFE27A",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Slippery Paws", "color": "yellow"}, {"text": ": 15 XP levels and a Slippery Paws Trophy!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
