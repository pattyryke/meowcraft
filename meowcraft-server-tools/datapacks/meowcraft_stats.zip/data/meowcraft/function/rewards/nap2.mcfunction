tag @s add mc_r_nap2
xp add @s 15 levels
give @s minecraft:white_wool[custom_name={text:"Professional Cat Napper Trophy",color:"#B9A3FF",italic:false},lore=[{text:"A Meowcraft title trophy =^.^=",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s ["", {"text": "   Reward for ", "color": "gray"}, {"text": "Professional Cat Napper", "color": "aqua"}, {"text": ": 15 XP levels and a Professional Cat Napper Trophy!", "color": "gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
