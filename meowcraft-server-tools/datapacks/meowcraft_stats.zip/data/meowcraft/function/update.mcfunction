# Every second: convert units, check titles and rewards, handle /trigger mystats and /trigger achievements
execute as @a run scoreboard players operation @s mc_fall = @s mc_fall_cm
scoreboard players operation @a mc_fall /= #100 mc_sys
execute as @a run scoreboard players operation @s mc_sneak = @s mc_sneak_t
scoreboard players operation @a mc_sneak /= #20 mc_sys
execute as @a run scoreboard players operation @s mc_nap = @s mc_nap_t
scoreboard players operation @a mc_nap /= #20 mc_sys

function meowcraft:check_titles
function meowcraft:check_rewards
function meowcraft:catnames

scoreboard players enable @a mystats
execute as @a[scores={mystats=1..}] run function meowcraft:mystats
scoreboard players enable @a achievements
execute as @a[scores={achievements=1..}] run function meowcraft:achievements

schedule function meowcraft:update 1s replace
