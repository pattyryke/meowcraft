team leave @s
tellraw @s {"text": "Title taken off.", "color": "gray"}
