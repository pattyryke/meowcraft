# Every second: convert units, check titles, handle /trigger mystats
execute as @a run scoreboard players operation @s mc_fall = @s mc_fall_cm
scoreboard players operation @a mc_fall /= #100 mc_sys
execute as @a run scoreboard players operation @s mc_sneak = @s mc_sneak_t
scoreboard players operation @a mc_sneak /= #20 mc_sys
execute as @a run scoreboard players operation @s mc_nap = @s mc_nap_t
scoreboard players operation @a mc_nap /= #20 mc_sys

function meowcraft:check_titles
function meowcraft:catnames

scoreboard players enable @a mystats
execute as @a[scores={mystats=1..}] run function meowcraft:mystats

schedule function meowcraft:update 1s replace
