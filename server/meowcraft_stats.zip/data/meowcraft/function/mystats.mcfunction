# Private stat card for whoever ran /trigger mystats
tellraw @s ["",{"text":"=^.^= ","color":"#B9A3FF"},{"selector":"@s","color":"light_purple"},{"text":"'s Silly Stats =^.^=","color":"#B9A3FF"}]
tellraw @s ["",{"text":" Faceplant: ","color":"#FF8FB1"},{"score":{"name":"@s","objective":"mc_fall"}},{"text":" blocks fallen","color":"gray"}]
tellraw @s ["",{"text":" Gremlin Mode: ","color":"#7FE0A8"},{"score":{"name":"@s","objective":"mc_sneak"}},{"text":" sec sneaking","color":"gray"}]
tellraw @s ["",{"text":" Nap Time: ","color":"#B9A3FF"},{"score":{"name":"@s","objective":"mc_nap"}},{"text":" sec asleep","color":"gray"}]
tellraw @s ["",{"text":" Bunny Hops: ","color":"#FFB38A"},{"score":{"name":"@s","objective":"mc_jumps"}}]
tellraw @s ["",{"text":" Dirt Hoarder: ","color":"#E0B07A"},{"score":{"name":"@s","objective":"mc_dirt"}},{"text":" dirt collected","color":"gray"}]
tellraw @s ["",{"text":" Butterfingers: ","color":"#FFE27A"},{"score":{"name":"@s","objective":"mc_drops"}},{"text":" items dropped","color":"gray"}]
scoreboard players set @s mystats 0
