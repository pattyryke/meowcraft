# Meowcraft Silly Stats - runs on server start and /reload

# Raw stats (counted by Minecraft itself)
scoreboard objectives add mc_fall_cm minecraft.custom:minecraft.fall_one_cm
scoreboard objectives add mc_sneak_t minecraft.custom:minecraft.sneak_time
scoreboard objectives add mc_jumps minecraft.custom:minecraft.jump {"text":"Bunny Hops","color":"light_purple","bold":true}
scoreboard objectives add mc_dirt minecraft.picked_up:minecraft.dirt {"text":"Dirt Hoarder","color":"gold","bold":true}
scoreboard objectives add mc_drops minecraft.custom:minecraft.drop {"text":"Butterfingers","color":"yellow","bold":true}
scoreboard objectives add mc_nap_t dummy

# Friendly display versions (converted units)
scoreboard objectives add mc_fall dummy {"text":"Faceplant (blocks fallen)","color":"red","bold":true}
scoreboard objectives add mc_sneak dummy {"text":"Gremlin Mode (sec sneaking)","color":"dark_green","bold":true}
scoreboard objectives add mc_nap dummy {"text":"Nap Time (sec asleep)","color":"aqua","bold":true}

# Helpers
scoreboard objectives add mc_sys dummy
scoreboard objectives add mystats trigger
scoreboard players set #100 mc_sys 100
scoreboard players set #20 mc_sys 20
scoreboard players set #6 mc_sys 6


# --- Cute sidebar styling ---
scoreboard players reset meow_footer
scoreboard players reset meow_space_bottom
scoreboard objectives modify mc_fall displayname ["", {"text": "☁ ", "color": "white"}, {"text": "Faceplant", "color": "#FF8FB1", "bold": true}, {"text": " ☁", "color": "white"}]
scoreboard objectives modify mc_fall numberformat styled {"color": "#FF8FB1", "bold": true}
scoreboard players set meow_space_top mc_fall 2147483647
scoreboard players display name meow_space_top mc_fall {"text":" "}
scoreboard players display numberformat meow_space_top mc_fall blank
scoreboard objectives modify mc_sneak displayname ["", {"text": "✦ ", "color": "white"}, {"text": "Gremlin Mode", "color": "#7FE0A8", "bold": true}, {"text": " ✦", "color": "white"}]
scoreboard objectives modify mc_sneak numberformat styled {"color": "#7FE0A8", "bold": true}
scoreboard players set meow_space_top mc_sneak 2147483647
scoreboard players display name meow_space_top mc_sneak {"text":" "}
scoreboard players display numberformat meow_space_top mc_sneak blank
scoreboard objectives modify mc_nap displayname ["", {"text": "☾ ", "color": "white"}, {"text": "Nap Time", "color": "#B9A3FF", "bold": true}, {"text": " ☾", "color": "white"}]
scoreboard objectives modify mc_nap numberformat styled {"color": "#B9A3FF", "bold": true}
scoreboard players set meow_space_top mc_nap 2147483647
scoreboard players display name meow_space_top mc_nap {"text":" "}
scoreboard players display numberformat meow_space_top mc_nap blank
scoreboard objectives modify mc_jumps displayname ["", {"text": "❀ ", "color": "white"}, {"text": "Bunny Hops", "color": "#FFB38A", "bold": true}, {"text": " ❀", "color": "white"}]
scoreboard objectives modify mc_jumps numberformat styled {"color": "#FFB38A", "bold": true}
scoreboard players set meow_space_top mc_jumps 2147483647
scoreboard players display name meow_space_top mc_jumps {"text":" "}
scoreboard players display numberformat meow_space_top mc_jumps blank
scoreboard objectives modify mc_dirt displayname ["", {"text": "✿ ", "color": "white"}, {"text": "Dirt Hoarder", "color": "#E0B07A", "bold": true}, {"text": " ✿", "color": "white"}]
scoreboard objectives modify mc_dirt numberformat styled {"color": "#E0B07A", "bold": true}
scoreboard players set meow_space_top mc_dirt 2147483647
scoreboard players display name meow_space_top mc_dirt {"text":" "}
scoreboard players display numberformat meow_space_top mc_dirt blank
scoreboard objectives modify mc_drops displayname ["", {"text": "♥ ", "color": "white"}, {"text": "Butterfingers", "color": "#FFE27A", "bold": true}, {"text": " ♥", "color": "white"}]
scoreboard objectives modify mc_drops numberformat styled {"color": "#FFE27A", "bold": true}
scoreboard players set meow_space_top mc_drops 2147483647
scoreboard players display name meow_space_top mc_drops {"text":" "}
scoreboard players display numberformat meow_space_top mc_drops blank

# Tab list always shows Bunny Hops
scoreboard objectives setdisplay list mc_jumps

# Start the loops
schedule function meowcraft:nap_check 5t replace
schedule function meowcraft:update 1s replace
schedule function meowcraft:rotate 1s replace
