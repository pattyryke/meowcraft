# Removes everything this datapack added. Run, then: datapack disable "file/meowcraft_stats.zip"
schedule clear meowcraft:nap_check
schedule clear meowcraft:update
schedule clear meowcraft:rotate
scoreboard objectives remove mc_fall_cm
scoreboard objectives remove mc_sneak_t
scoreboard objectives remove mc_jumps
scoreboard objectives remove mc_dirt
scoreboard objectives remove mc_drops
scoreboard objectives remove mc_nap_t
scoreboard objectives remove mc_fall
scoreboard objectives remove mc_sneak
scoreboard objectives remove mc_nap
scoreboard objectives remove mc_sys
scoreboard objectives remove mystats
tag @a remove mc_t_fall1
tag @a remove mc_t_fall2
tag @a remove mc_t_sneak1
tag @a remove mc_t_sneak2
tag @a remove mc_t_nap1
tag @a remove mc_t_nap2
tag @a remove mc_t_jump1
tag @a remove mc_t_jump2
tag @a remove mc_t_dirt1
tag @a remove mc_t_dirt2
tag @a remove mc_t_drop1
tag @a remove mc_t_drop2
