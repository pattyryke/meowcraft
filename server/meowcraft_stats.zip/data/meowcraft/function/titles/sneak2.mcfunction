tag @s add mc_t_sneak2
tellraw @a ["",{"text":"[Meowcraft] ","color":"dark_purple"},{"selector":"@s","color":"dark_green"},{"text":" has sneaked for an HOUR. Nobody has seen their face in weeks.","color":"white"}]
tellraw @a ["",{"text":"   New title: ","color":"gray"},{"text":"Shadow Goblin Supreme","color":"dark_green","bold":true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
