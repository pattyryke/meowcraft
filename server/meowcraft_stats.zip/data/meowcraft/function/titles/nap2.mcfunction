tag @s add mc_t_nap2
tellraw @a ["",{"text":"[Meowcraft] ","color":"dark_purple"},{"selector":"@s","color":"aqua"},{"text":" has napped for 5 minutes total. Peak cat behavior.","color":"white"}]
tellraw @a ["",{"text":"   New title: ","color":"gray"},{"text":"Professional Cat Napper","color":"aqua","bold":true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
