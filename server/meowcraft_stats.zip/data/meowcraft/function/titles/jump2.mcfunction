tag @s add mc_t_jump2
tellraw @a ["",{"text":"[Meowcraft] ","color":"dark_purple"},{"selector":"@s","color":"light_purple"},{"text":" has jumped 10,000 times. Their knees have filed a complaint.","color":"white"}]
tellraw @a ["",{"text":"   New title: ","color":"gray"},{"text":"Hop Lord","color":"light_purple","bold":true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
