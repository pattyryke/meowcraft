tag @s add mc_t_dirt1
tellraw @a ["",{"text":"[Meowcraft] ","color":"dark_purple"},{"selector":"@s","color":"gold"},{"text":" has collected 500 dirt. For what purpose??","color":"white"}]
tellraw @a ["",{"text":"   New title: ","color":"gray"},{"text":"Dirt Enthusiast","color":"gold","bold":true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
