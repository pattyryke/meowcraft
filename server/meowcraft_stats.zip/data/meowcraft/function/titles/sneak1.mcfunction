tag @s add mc_t_sneak1
tellraw @a ["",{"text":"[Meowcraft] ","color":"dark_purple"},{"selector":"@s","color":"dark_green"},{"text":" has sneaked for 10 whole minutes. What are they hiding?","color":"white"}]
tellraw @a ["",{"text":"   New title: ","color":"gray"},{"text":"Certified Gremlin","color":"dark_green","bold":true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
