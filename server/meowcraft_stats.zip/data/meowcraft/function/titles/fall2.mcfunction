tag @s add mc_t_fall2
tellraw @a ["",{"text":"[Meowcraft] ","color":"dark_purple"},{"selector":"@s","color":"red"},{"text":" has fallen 5,000 blocks. The ground knows them by name.","color":"white"}]
tellraw @a ["",{"text":"   New title: ","color":"gray"},{"text":"Gravity's Favorite Toy","color":"red","bold":true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
