tag @s add mc_t_drop2
tellraw @a ["",{"text":"[Meowcraft] ","color":"dark_purple"},{"selector":"@s","color":"yellow"},{"text":" has dropped 1,000 items. Paws are not hands.","color":"white"}]
tellraw @a ["",{"text":"   New title: ","color":"gray"},{"text":"Slippery Paws","color":"yellow","bold":true}]
execute as @a at @s run playsound minecraft:entity.cat.ambient master @s ~ ~ ~ 1 1
